## BACALAH KETENTUAN DENGAN SEKSAMA - KAMI AKAN MENGANGGAP GUGUR JIKA PROSES TIDAK SESUAI
## LANGKAH PENGERJAAN TEST BATCH III DAN KETENTUAN

1. Clone project test dengan cara - git clone -b master --alamat url repository
2. sebelum mengerjakan test  buat branch baru dengan format nama/       test-fe-kawahedukasi contoh: 
        - git branch hambaly/test-fe-kawahedukasi
        - git checkout hambaly/test-fe-kawahedukasi
3. kemudian kerjakan projek yang berada di file test-introduction.txt, untuk bahasa pemrograman di sarankan hanya menggunakan javascript, php, java dan buatlah file dengan extention berikut
4. setelah selesai mengerjakan lalu push ke branch yang sudah tadi di buat dengan cara: 
    - git add .
    - git commit -m " Nama : Test Kawah Edukasi bath III "
    - git push origin nama/test-fe-kawahedukasi

    note: untuk nama diisi sesuai nama pribadi dan branch yang sudah di buat dengan nama pribadi contoh : hambaly/test-fe-kawahedukasi
5. peserta wajib push hasil test di jam 3 sore, jika peserta kurang atau melebihi jam tersebut di anggap gugur
6. test hanya berlaku satu hari tidak melebihi di hari senin jam 3 sore
7. Jika peserta terlihat kerjasama atau saling contek code program satu sama lain sama maka akan di pastikan gugur / tidak diterima
8. jika kode program sama maka akan di pastikan gugur


## SELAMAT MENGERJAKAN