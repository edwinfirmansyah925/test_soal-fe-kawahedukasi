function segiTiga(angka) {
    let jwb1 = "";
    let jwb2 = "";
    for (let i = 0; i < angka / 1 - 5; i++) {
      for (let j = 0; j <= i; j++) {
        jwb1 += "* ";
      }
      jwb1 += "\n";
    }
  
    for (let i = angka / 2 - 1; i > 0; i--) {
      for (let j = 0; j <= angka / 1 - 6; j++) {
        if (j >= i) {
          jwb2 += "* ";
        } else {
          jwb2 += "  ";
        }
      }
      jwb2 += "\n";
    }
    console.log(jwb1);
    console.log(jwb2);
  }
  segiTiga(11);